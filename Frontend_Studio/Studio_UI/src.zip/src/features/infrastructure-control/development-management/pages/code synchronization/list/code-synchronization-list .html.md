<div class="app-list-page"> 
 
 
    <!-- ========================================================= 
        PAGE HEADER 
    ========================================================= --> 
 
    <app-page-header 
 
        title="Code Synchronization" 
 
        subtitle="Manage generated code synchronization." 
 
        icon="fas fa-code"> 
 
 
        <!-- ===================================================== 
            PAGE HEADER CENTER 
        ====================================================== --> 
 
        <div pageHeaderCenter> 
 
            <app-search-box 
 
                [(value)]="searchText" 
 
                placeholder="Search submenus..." 
 
                (valueChange)="onSearch($event)"> 
 
            </app-search-box> 
 
        </div> 
 
 
        <!-- ===================================================== 
            PAGE HEADER RIGHT 
        ====================================================== --> 
 
        <div pageHeaderRight> 
 
            <app-command-center 
 
                command1Text="Refresh" 
 
                command1Icon="fas fa-rotate-right" 
 
                (command1Click)="refresh()" 
 
 
                command2Text="FE Rebuild" 
 
                command2Icon="fab fa-angular" 
 
                (command2Click)="rebuildFrontend()" 
 
 
                command3Text="BE Rebuild" 
 
                command3Icon="fas fa-server" 
 
                (command3Click)="rebuildBackend()" 
 
 
                rightCommandIcon="fas fa-clock-rotate-left" 
 
                (rightCommandClick)="openHistory()"> 
 
            </app-command-center> 
 
        </div> 
 
    </app-page-header> 
 
 
 
    <!-- ========================================================= 
        PAGE TOOLBAR 
    ========================================================= --> 
 
    <app-page-toolbar 
 
        leftFlex="0 0 auto" 
 
        rightFlex="1 1 auto"> 
 
 
        <!-- ===================================================== 
            LEFT 
        ====================================================== --> 
 
        <div pageToolbarLeft> 
 
            <!-- ================================================= 
                SYNCHRONIZATION TYPE 
            ================================================== --> 
 
            <app-control-tabs 
 
                [tabs]="tabs" 
 
                [selectedTab]="selectedTab" 
 
                (selectedTabChange)="onSelectedTabChange($event)"> 
 
            </app-control-tabs> 
 
        </div> 
 
 
        <!-- ===================================================== 
            RIGHT 
        ====================================================== --> 
 
        <div pageToolbarRight> 
 
 
            <!-- ================================================= 
                MODULE FILTER 
            ================================================== --> 
 
            <app-search-dropdown 
 
                placeholder="Select Module" 
 
                [items]="modules" 
 
                labelField="text" 
 
                valueField="value" 
 
                [(value)]="selectedModuleId" 
 
                (valueChange)="onModuleChange($event)"> 
 
            </app-search-dropdown> 
 
 
            <!-- ================================================= 
                MENU FILTER 
            ================================================== --> 
 
            <app-search-dropdown 
 
                placeholder="Select Menu" 
 
                [items]="menus" 
 
                labelField="text" 
 
                valueField="value" 
 
                [(value)]="selectedMenuId" 
 
                (valueChange)="onMenuChange($event)"> 
 
            </app-search-dropdown> 
 
 
            <!-- ================================================= 
                STATUS FILTER 
            ================================================== --> 
 
            <app-search-dropdown 
 
                placeholder="Select Status" 
 
                [items]="statuses" 
 
                labelField="text" 
 
                valueField="value" 
 
                [(value)]="selectedStatus" 
 
                (valueChange)="onStatusChange($event)"> 
 
            </app-search-dropdown> 
 
        </div> 
 
    </app-page-toolbar> 
 
 
 
    <!-- ========================================================= 
        PAGE CANVAS 
    ========================================================= --> 
 
    <app-page-canvas 
 
        [config]="canvasConfig"> 
 
 
        <!-- ===================================================== 
            CANVAS BODY 
        ====================================================== --> 
 
        <div canvasBody> 
 
            <app-list-table 
 
                [columns]="columns" 
 
                [rows]="pagedSynchronizations" 
 
                [serialOffset]=" 
                    (currentPage - 1) * pageSize 
                " 
 
                [loading]="loading" 
 
                [error]="loadFailed" 
 
                [showRegistration]=" 
                    selectedTab === 'backend' 
                " 
 
                [actions]="{ 
                    view: true, 
                    edit: false, 
                    delete: false 
                }" 
 
                (view)="view($event)" 
 
                (operation)="synchronize($event)" 
 
                (registration)="register($event)" 
 
                (database)="database($event)" 
 
                (sortChange)="onSort($event)"> 
 
            </app-list-table> 
 
        </div> 
 
 
        <!-- ===================================================== 
            CANVAS FOOTER 
        ====================================================== --> 
 
        <app-pagination 
 
            canvasFooter 
 
            [totalRecords]=" 
                filteredSynchronizations.length 
            " 
 
            [currentPage]="currentPage" 
 
            [pageSize]="pageSize" 
 
            (pageChange)="onPageChange($event)" 
 
            (pageSizeChange)="onPageSizeChange($event)"> 
 
        </app-pagination> 
 
    </app-page-canvas> 
 
 
 
    <!-- ========================================================= 
        CODE VIEWER 
    ========================================================= --> 
 
    <app-code-viewer 
 
        [opened]="codeViewerOpened" 
 
        [synchronizationType]=" 
            selectedTab === 'backend' 
                ? 'Backend' 
                : 'Frontend' 
        " 
 
        [files]="codeViewerFiles" 
 
        (closed)="closeCodeViewer()" 
 
        (restoreRequested)="onCodeViewerRestoreAll()" 
 
        (restoreFileRequested)="onCodeViewerRestoreFile($event)"> 
 
    </app-code-viewer> 
 
 
 
    <!-- ========================================================= 
        HISTORY DRAWER 
    ========================================================= --> 
 
    <app-history-drawer 
 
        [opened]="historyOpened" 
 
        [title]="historyTitle" 
 
        [items]="historyItems" 
 
        (closed)="closeHistory()"> 
 
    </app-history-drawer> 
 
 
 
    <!-- ========================================================= 
        TOAST 
    ========================================================= --> 
 
    <app-toast> 
 
    </app-toast> 
 
 
 
    <!-- ========================================================= 
        CONFIRM DIALOG 
    ========================================================= --> 
 
    <app-confirm-dialog> 
 
    </app-confirm-dialog> 
 
 
 
    <!-- ========================================================= 
        PROGRESS DIALOG 
    ========================================================= --> 
 
    <app-progress-dialog> 
 
    </app-progress-dialog> 
 
</div>