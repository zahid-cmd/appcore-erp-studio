/* ============================================================
   Sub Ordinate Components
============================================================ */

export interface SubOrdinateComponents
{
    id:
        number;


    //===========================================================
    // Section 1 - General Information
    //===========================================================

    code:
        string;

    name:
        string;

    tabName:
        string;

    icon:
        string;


    //===========================================================
    // Section 2 - Component Information
    //===========================================================

    folderName:
        string;

    featureFolder:
        string;

    featureSubFolder:
        string;

    componentPath:
        string;


    //===========================================================
    // Section 3 - File & Registration Information
    //===========================================================

    registrationFilePath:
        string;

    htmlFilePath:
        string;

    tsFilePath:
        string;

    cssFilePath:
        string;


    //===========================================================
    // Section 4 - Status & Additional Information
    //===========================================================

    displayOrder:
        number;

    status:
        boolean;

    remarks:
        string;


    //===========================================================
    // Section 5 - Background Image Configuration
    //===========================================================

    lightBackgroundImagePath:
        string;

    deepBackgroundImagePath:
        string;
}



/* ============================================================
   Create Sub Ordinate Components
============================================================ */

export interface CreateSubOrdinateComponents
{
    //===========================================================
    // Section 1 - General Information
    //===========================================================

    name:
        string;

    tabName:
        string;

    icon:
        string;


    //===========================================================
    // Section 2 - Component Information
    //===========================================================

    folderName:
        string;

    featureFolder:
        string;

    featureSubFolder:
        string;

    componentPath:
        string;


    //===========================================================
    // Section 3 - File & Registration Information
    //===========================================================

    registrationFilePath:
        string;

    htmlFilePath:
        string;

    tsFilePath:
        string;

    cssFilePath:
        string;


    //===========================================================
    // Section 4 - Status & Additional Information
    //===========================================================

    displayOrder:
        number;

    status:
        boolean;

    remarks:
        string;


    //===========================================================
    // Section 5 - Background Image Configuration
    //===========================================================

    lightBackgroundImage:
        File | null;

    deepBackgroundImage:
        File | null;
}



/* ============================================================
   Update Sub Ordinate Components
============================================================ */

export interface UpdateSubOrdinateComponents
{
    id:
        number;


    //===========================================================
    // Section 1 - General Information
    //===========================================================

    name:
        string;

    tabName:
        string;

    icon:
        string;


    //===========================================================
    // Section 2 - Component Information
    //===========================================================

    folderName:
        string;

    featureFolder:
        string;

    featureSubFolder:
        string;

    componentPath:
        string;


    //===========================================================
    // Section 3 - File & Registration Information
    //===========================================================

    registrationFilePath:
        string;

    htmlFilePath:
        string;

    tsFilePath:
        string;

    cssFilePath:
        string;


    //===========================================================
    // Section 4 - Status & Additional Information
    //===========================================================

    displayOrder:
        number;

    status:
        boolean;

    remarks:
        string;


    //===========================================================
    // Section 5 - Background Image Configuration
    //===========================================================

    lightBackgroundImage:
        File | null;

    deepBackgroundImage:
        File | null;

    removeLightBackgroundImage:
        boolean;

    removeDeepBackgroundImage:
        boolean;
}



/* ============================================================
   Sub Ordinate Components Defaults
============================================================ */

export interface SubOrdinateComponentsDefaults
{
    code:
        string;
}