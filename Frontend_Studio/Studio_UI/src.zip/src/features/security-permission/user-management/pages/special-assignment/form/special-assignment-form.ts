//===============================================================
// Imports
//===============================================================

import
{
    Component,
    OnInit,
    ChangeDetectorRef,
    inject
}
from '@angular/core';

import
{
    CommonModule
}
from '@angular/common';

import
{
    ActivatedRoute,
    Router
}
from '@angular/router';

import
{
    FormsModule
}
from '@angular/forms';


//===============================================================
// Shared Components
//===============================================================

import
{
    PageCanvasComponent,
    PageCanvasConfig
}
from '../../../../../../shared/components/layout/page-canvas/page-canvas';

import
{
    PageHeaderComponent
}
from '../../../../../../shared/components/layout/page-header/page-header';

import
{
    PageToolbarComponent
}
from '../../../../../../shared/components/layout/page-toolbar/page-toolbar';

import
{
    ItemCart,
    ItemCartColumn,
    ItemCartRow
}
from '../../../../../../shared/components/layout/item-cart/item-cart';

import
{
    CommandCenterComponent
}
from '../../../../../../shared/components/utilities/command-center/command-center';

import
{
    ControlTabsComponent,
    ControlTab
}
from '../../../../../../shared/components/controls/control-tabs/control-tabs';

import
{
    SearchDropdownComponent
}
from '../../../../../../shared/components/controls/search-dropdown/search-dropdown';

import
{
    ToastComponent
}
from '../../../../../../shared/components/utilities/toast/toast';

import
{
    ToastService
}
from '../../../../../../shared/components/utilities/toast/toast.service';

import
{
    ConfirmDialogComponent
}
from '../../../../../../shared/components/utilities/confirm-dialog/confirm-dialog';

import
{
    ConfirmDialogService
}
from '../../../../../../shared/components/utilities/confirm-dialog/confirm-dialog.service';

import
{
    PaginationComponent
}
from '../../../../../../shared/components/controls/pagination/pagination';

import
{
    ActivityItem,
    PageSlot,
    buildPageSlots
}
from '../../../../../../shared/components/utilities/activity-selector/activity-selector';

import
{
    RecordCounterComponent
}
from '../../../../../../shared/components/utilities/record-counter/record-counter';

import
{
    ProgressDialogComponent
}
from '../../../../../../shared/components/utilities/progress-dialog/progress-dialog';

import
{
    SearchBoxComponent
}
from '../../../../../../shared/components/utilities/search-box/search-box';


//===============================================================
// Models & Services
//===============================================================

import
{
    SpecialAssignment,
    SpecialAssignmentPermission
}
from '../../../models/special-assignment.model';

import
{
    SpecialAssignmentService
}
from '../../../services/special-assignment.service';

import
{
    UserProfileService
}
from '../../../services/user-profile.service';

import
{
    ModuleService
}
from '../../../../../infrastructure-control/navigation-management/services/module.service';

import
{
    NavigationMenuService
}
from '../../../../../infrastructure-control/navigation-management/services/menu.service';

import
{
    NavigationSubmenuService
}
from '../../../../../infrastructure-control/navigation-management/services/submenu.service';

import
{
    MasterActivityService
}
from '../../../../../infrastructure-control/navigation-management/services/master-activity.service';


import
{
    RecordCounterSection
}
from '../../../../../../shared/components/utilities/record-counter/record-counter.model';

import
{
    ProgressDialogService
}
from '../../../../../../shared/components/utilities/progress-dialog/progress-dialog.service';


//===============================================================
// Save Payload
//===============================================================

interface SpecialAssignmentSavePayload
{
    specialAssignmentId?: number;

    userProfileId: number;

    isActive: boolean;

    details:
        SpecialAssignmentSaveDetail[];
}


interface SpecialAssignmentSaveDetail
{
    specialAssignmentDetailId?: number;

    specialAssignmentId?: number;

    moduleId: number;

    menuId: number;

    subMenuId: number;

    isActive: boolean;

    permissions:
        SpecialAssignmentSavePermission[];
}


interface SpecialAssignmentSavePermission
{
    specialAssignmentPermissionId?: number;

    masterActivityId: number | null;

    navigationActivityId: number | null;

    isActive: boolean;
}


//===============================================================
// Component
//===============================================================


@Component(
{
    selector:'app-special-assignment-form',

    standalone:true,

    imports:
    [
        CommonModule,
        FormsModule,

        PageCanvasComponent,
        PageHeaderComponent,
        RecordCounterComponent,
        SearchBoxComponent,
        PageToolbarComponent,

        ItemCart,

        CommandCenterComponent,
        ControlTabsComponent,
        SearchDropdownComponent,

        ToastComponent,
        ConfirmDialogComponent,
        PaginationComponent,
        ProgressDialogComponent
    ],

    templateUrl:'./special-assignment-form.html',

    styleUrls:
    [
        './special-assignment-form.css'
    ]
})


export class SpecialAssignmentForm
implements OnInit
{

    //===========================================================
    // Injection
    //===========================================================

    private readonly route =
        inject(ActivatedRoute);


    private readonly router =
        inject(Router);


    private readonly specialAssignmentService =
        inject(SpecialAssignmentService);


    private readonly confirmDialog =
        inject(ConfirmDialogService);


    private readonly toast =
        inject(ToastService);


    private readonly cdr =
        inject(ChangeDetectorRef);


    private readonly userProfileService =
        inject(UserProfileService);


    private readonly moduleService =
        inject(ModuleService);


    private readonly menuService =
        inject(NavigationMenuService);


    private readonly submenuService =
        inject(NavigationSubmenuService);


    private readonly masterActivityService =
        inject(MasterActivityService);




    private readonly progressDialog =
        inject(ProgressDialogService);


    //===========================================================
    // Mode
    //===========================================================

    mode:
        'add' | 'edit' | 'view'
        =
        'add';


    specialAssignmentId =
        0;


    //===========================================================
    // Save Button Text
    //===========================================================

    get saveButtonText():
        string
    {
        return this.mode === 'edit'
            ?
            'Update'
            :
            'Save';
    }


    //===========================================================
    // Tab Change
    //===========================================================

    onTabChange(
        tab:string
    ):
        void
    {
        this.selectedTab =
            tab;
    }


    //===========================================================
    // Header
    //===========================================================

    pageTitle =
        'Special Assignment';


    entityName =
        'Special Assignment';


    selectedTab =
        'general';


    //===========================================================
    // Tab Title
    //===========================================================

    get tabTitle():
        string
    {
        switch(this.mode)
        {
            case 'add':

                return `Add ${this.entityName}`;


            case 'edit':

                return `Update ${this.entityName}`;


            case 'view':

                return `View ${this.entityName}`;


            default:

                return this.entityName;
        }
    }


    //===========================================================
    // Tabs
    //===========================================================

    get tabs():
        ControlTab[]
    {
        return [
        {
            id:'general',

            label:this.tabTitle
        }];
    }


    //===========================================================
    // Pagination
    //===========================================================

    currentPage =
        1;


    pageSize =
        10;


    //===========================================================
    // Activity Search
    //===========================================================

    activitySearchText =
        '';


    //===========================================================
    // Loading State
    //===========================================================

    loading =
        false;


    orbitLoading =
        false;


    loadFailed =
        false;


    //===========================================================
    // Header Activity Checkbox
    //===========================================================

    headerCheckboxStates:
    {
        [field:string]:boolean;
    } =
    {
        all:false,
        view:false,
        add:false,
        update:false,
        delete:false,
        restore:false
    };


    //===========================================================
    // Activity Loading Tracker
    //===========================================================

    private pendingActivityLoads =
        0;


    private completedActivityLoads =
        0;


    //===========================================================
    // Page Canvas Configuration
    //===========================================================

    readonly canvasConfig:
        PageCanvasConfig =
    {
        mode:'list',

        showHeader:false,

        showFooter:true,

        reserveFooterSpace:true,

        bodyScrollable:true,

        fixedHeight:true,

        visibleRows:10,

        rowHeight:32,

        headerHeight:36,

        footerHeight:56
    };


    //===========================================================
    // Selection Collections
    //===========================================================

    userProfiles:
        any[] =
    [
    ];


    modules:
        any[] =
    [
    ];


    menus:
        any[] =
    [
    ];


    subMenus:
        any[] =
    [
    ];


    //===========================================================
    // Activity Collections
    //===========================================================

    masterActivities:
        ActivityItem[] =
    [
    ];

    //===========================================================
    // Page Actions
    //
    // Common activities show on every row. A Page activity
    // (Approve, Post, Settlement ...) shows only on the rows of
    // the pages it is linked to on the Navigation Activities page.
    //===========================================================
    private pageActivityPages =
        new Map<number, Set<number>>();
    // Page actions used in the table, in a fixed order : each keeps
    // the same column on every row of the grid.
    pageSlots:
        PageSlot[] =
    [
    ];
    private activitiesFor
    (
        subMenuId:number
    ):
        ActivityItem[]
    {
        return this.masterActivities.filter
        (
            activity =>
                activity.group !== 'page'
                ||
                (
                    this.pageActivityPages
                        .get(activity.id)
                        ?.has(Number(subMenuId))
                    ??
                    false
                )
        );
    }



    //===========================================================
    // Selection State
    //===========================================================

    isAddDisabled =
        true;


    //===========================================================
    // Selected Values
    //===========================================================

    selectedUserProfileId:
        number | null =
        null;


    selectedModuleId:
        number | null =
        null;


    selectedMenuId:
        number | null =
        null;


    selectedSubMenuId:
        number | null =
        null;


    //===========================================================
    // Special Assignment
    //===========================================================

    specialAssignment:
        SpecialAssignment =
    {
        specialAssignmentId:0,

        userProfileId:0,

        userProfileName:'',

        pageCount:0,

        masterActivityCount:0,

        specialActivityCount:0,

        totalActivityCount:0,

        isActive:true,

        details:[]
    };


    //===========================================================
    // State
    //===========================================================

    private originalSpecialAssignment =
        '';


    //===========================================================
    // Edit Cart Initialization
    //
    // Existing database rows are restored into the cart only once.
    // After that, the cart becomes the working source of truth
    // until Update is saved.
    //===========================================================

    private editCartInitialized =
        false;


    hasChanges =
        false;


    //===========================================================
    // User Profile Lock
    //===========================================================

    isUserProfileLocked =
        false;


    //===========================================================
    // Default Collections
    //===========================================================

    private readonly defaultModules =
    [
        {
            id:0,

            code:'',

            name:'All Modules'
        }
    ];


    private readonly defaultMenus =
    [
        {
            id:0,

            code:'',

            name:'All Menus'
        }
    ];


    private readonly defaultSubMenus =
    [
        {
            id:0,

            code:'',

            name:'All Sub Menus'
        }
    ];


    private infrastructureControlModuleIds:
        number[] =
    [
    ];


    //===========================================================
    // Infrastructure Control Access
    //===========================================================

    private isInfrastructureControlAllowed():
        boolean
    {
        const userProfile =
            this.userProfiles.find(
                profile =>
                    Number(
                        profile?.id
                        ??
                        profile?.userProfileId
                        ??
                        profile?.UserProfileId
                    )
                    ===
                    Number(
                        this.selectedUserProfileId
                    )
            );


        const userProfileCode =
            userProfile?.profileCode
            ??
            userProfile?.ProfileCode
            ??
            userProfile?.code
            ??
            userProfile?.Code
            ??
            '';


        return String(
            userProfileCode
        )
            .trim()
            .toUpperCase()
            ===
            'RP001';
    }


    private isInfrastructureControlModule
    (
        module:any
    ):
        boolean
    {
        return String(
            module?.name
            ??
            module?.moduleName
            ??
            module?.Name
            ??
            module?.ModuleName
            ??
            ''
        )
            .trim()
            .toLowerCase()
            ===
            'infrastructure control';
    }


    private isInfrastructureControlModuleId
    (
        moduleId:number | null
    ):
        boolean
    {
        return this.infrastructureControlModuleIds.includes(
            Number(
                moduleId
            )
        );
    }


    private containsInfrastructureControlRow():
        boolean
    {
        return this.itemCartRows.some(
            row =>
                this.isInfrastructureControlModuleId(
                    row.moduleId
                )
        );
    }



    //===========================================================
    // Item Cart Rows
    //===========================================================

    itemCartRows:
        ItemCartRow[] =
    [
    ];


    pagedItemCartRows:
        ItemCartRow[] =
    [
    ];


    //===========================================================
    // Item Cart Columns
    //===========================================================

    readonly itemCartColumns:
        ItemCartColumn[] =
    [
        {
            header:'#',

            field:'serial',

            type:'serial',

            width:'50px',

            align:'center'
        },

        {
            header:'Sub Menu',

            field:'subMenu',

            type:'text',

            width:'240px',

            align:'left'
        },

        {
            header:'Master Activities',

            field:'masterActivities',

            type:'masterActivities',

            align:'center',

            headerCheckbox:true
        },

        {
            header:'Action',

            field:'action',

            type:'action',

            width:'50px',

            align:'center'
        }
    ];


    //===========================================================
    // Column "All" box (header) : tick / clear these activities
    // on every row. New row objects, so every row redraws.
    //===========================================================

    onColumnCheckboxChange
    (
        event:
        {
            ids:number[];
            checked:boolean;
        }
    ):
        void
    {
        if
        (
            this.isViewMode
        )
        {
            return;
        }

        this.itemCartRows =
            this.itemCartRows.map(
                row =>
                ({
                    ...row,
                    masterActivities:
                        row.masterActivities.map(
                            activity =>
                                event.ids.includes(activity.id)
                                    ? { ...activity, checked:event.checked }
                                    : activity
                        )
                })
            );

        this.updatePagination();
        this.updateHeaderCheckboxStates();
        this.cdr.detectChanges();
    }


    //===========================================================
    // Header Activity Checkbox Changed
    //===========================================================

    onHeaderCheckboxStateChanged
    (
        event:
        {
            field:string;
            checked:boolean;
        }
    ):
        void
    {
        this.headerCheckboxStates[
            event.field
        ] =
            event.checked;

        switch(event.field)
        {
            case 'all':
                this.toggleAllActivities(
                    event.checked
                );
                break;

            case 'view':
                this.toggleActivityByType(
                    'view',
                    event.checked
                );
                break;

            case 'add':
                this.toggleActivityByType(
                    'add',
                    event.checked
                );
                break;

            case 'update':
                this.toggleActivityByType(
                    'update',
                    event.checked
                );
                break;

            case 'delete':
                this.toggleActivityByType(
                    'delete',
                    event.checked
                );
                break;

            case 'restore':
                this.toggleActivityByType(
                    'restore',
                    event.checked
                );
                break;
        }

        this.updatePagination();
        this.updateHeaderCheckboxStates();
        this.detectChanges();
        this.cdr.detectChanges();
    }

    //===========================================================
    // Toggle All Activities
    //===========================================================

    private toggleAllActivities
    (
        checked:boolean
    ):
        void
    {
        this.itemCartRows =
            this.itemCartRows.map(
                row =>
                ({
                    ...row,

                    masterActivities:
                        row.masterActivities.map(
                            activity =>
                            ({
                                ...activity,
                                checked
                            })
                        )
                })
            );

        this.updatePagination();
        this.updateHeaderCheckboxStates();
    }

    //===========================================================
    // Toggle Activity By Type
    //===========================================================

    private toggleActivityByType
    (
        type:
            'view'
            |
            'add'
            |
            'update'
            |
            'delete'
            |
            'restore',
        checked:boolean
    ):
        void
    {
        this.itemCartRows =
            this.itemCartRows.map(
                row =>
                ({
                    ...row,

                    masterActivities:
                        row.masterActivities.map(
                            activity =>
                            this.isActivityType(
                                activity,
                                type
                            )
                            ?
                            {
                                ...activity,
                                checked
                            }
                            :
                            activity
                        )
                })
            );

        this.updatePagination();
        this.updateHeaderCheckboxStates();
    }

    //===========================================================
    // Activity Type
    //===========================================================

    private isActivityType
    (
        activity:ActivityItem,
        type:
            'view'
            |
            'add'
            |
            'update'
            |
            'delete'
            |
            'restore'
    ):
        boolean
    {
        const activityText =
            String(
                activity?.text
                ??
                ''
            )
                .trim()
                .toLowerCase()
                .replace(
                    /[^a-z]/g,
                    ''
                );

        switch(type)
        {
            case 'view':
                return activityText === 'view';

            case 'add':
                return (
                    activityText === 'add'
                    ||
                    activityText === 'create'
                );

            case 'update':
                return (
                    activityText === 'update'
                    ||
                    activityText === 'edit'
                );

            case 'delete':
                return activityText === 'delete';

            case 'restore':
                return activityText === 'restore';

            default:
                return false;
        }
    }


    //===========================================================
    // Activity Changed
    //===========================================================

    onActivityChanged():
        void
    {
        this.updateHeaderCheckboxStates();

        this.detectChanges();
    }


    //===========================================================
    // Remove Item
    //===========================================================

    onRemoveItem
    (
        row:ItemCartRow
    ):
        void
    {
        this.itemCartRows =
            this.itemCartRows.filter(
                item =>
                    item.subMenuId !== row.subMenuId
            );


        //=======================================================
        // Update User Profile Lock
        //=======================================================

        this.updateUserProfileLock();


        this.updatePagination();

        this.updateHeaderCheckboxStates();

        this.detectChanges();
    }


    //===========================================================
    // Update Header Checkbox States
    //===========================================================

    updateHeaderCheckboxStates():
        void
    {
        const activities =
            this.itemCartRows.flatMap(
                row =>
                    row.masterActivities
            );

        const getState =
            (
                type:
                    'view'
                    |
                    'add'
                    |
                    'update'
                    |
                    'delete'
                    |
                    'restore'
            ):
                boolean =>
            {
                const matchingActivities =
                    activities.filter(
                        activity =>
                            this.isActivityType(
                                activity,
                                type
                            )
                    );

                return (
                    matchingActivities.length > 0
                    &&
                    matchingActivities.every(
                        activity =>
                            activity.checked
                    )
                );
            };

        this.headerCheckboxStates =
        {
            all:
                activities.length > 0
                &&
                activities.every(
                    activity =>
                        activity.checked
                ),

            view:
                getState('view'),

            add:
                getState('add'),

            update:
                getState('update'),

            delete:
                getState('delete'),

            restore:
                getState('restore')
        };

        this.cdr.detectChanges();
    }


    //===========================================================
    // Filtered Item Cart Rows
    //===========================================================

    getFilteredItemCartRows():
        ItemCartRow[]
    {
        const search =
            this.activitySearchText
                .trim()
                .toLowerCase();


        if
        (
            !search
        )
        {
            return this.itemCartRows;
        }


        return this.itemCartRows.filter(
            row =>
                String(
                    row.menu
                    ??
                    ''
                )
                .toLowerCase()
                .includes(search)
                ||
                String(
                    row.subMenu
                    ??
                    ''
                )
                .toLowerCase()
                .includes(search)
        );
    }


    //===========================================================
    // Activity Search
    //===========================================================

    onActivitySearch(
        value:string
    ):
        void
    {
        this.activitySearchText =
            value
            ??
            '';


        this.currentPage =
            1;


        this.updatePagination();

        this.cdr.detectChanges();
    }


    //===========================================================
    // Update Pagination
    //===========================================================

    updatePagination():
        void
    {
        const filteredRows =
            this.getFilteredItemCartRows();


        const totalPages =

            Math.max(

                1,

                Math.ceil(

                    filteredRows.length
                    /
                    this.pageSize

                )
            );


        if
        (
            this.currentPage > totalPages
        )
        {
            this.currentPage =
                totalPages;
        }


        const start =

            (
                this.currentPage - 1
            )
            *
            this.pageSize;


        this.pagedItemCartRows =

            filteredRows.slice(

                start,

                start + this.pageSize
            );
    }


    //===========================================================
    // Page Change
    //===========================================================

    onPageChange
    (
        page:number
    ):
        void
    {
        this.currentPage =
            page;


        this.updatePagination();
    }


    //===========================================================
    // Page Size Change
    //===========================================================

    onPageSizeChange
    (
        pageSize:number
    ):
        void
    {
        this.pageSize =
            pageSize;


        this.currentPage =
            1;


        this.updatePagination();
    }


    //===========================================================
    // Init
    //===========================================================

    ngOnInit():
        void
    {
        this.initializeMode();

        this.loadUserProfiles();

        this.loadModules();

        this.loadMasterActivities();

        this.updatePagination();

        this.updateUserProfileLock();
    }


    //===========================================================
    // Load User Profiles
    //===========================================================
    //
    // ADD MODE RULE:
    // A User Profile that already has a Special Assignment in
    // the database must NOT be available for a new assignment.
    //
    // EDIT / VIEW MODE RULE:
    // The complete User Profile list remains available because
    // the existing assigned User Profile must be displayed.
    //
    // The Special Assignment list endpoint is used as the
    // database source of truth for already-configured users.
    //===========================================================

    private loadUserProfiles():
        void
    {
        //=======================================================
        // EDIT / VIEW
        //=======================================================

        if
        (
            this.mode !== 'add'
        )
        {
            this.loadAllUserProfiles();

            return;
        }


        //=======================================================
        // ADD
        //
        // First load all User Profiles.
        // Then load existing Special Assignments and remove
        // every User Profile already configured in the database.
        //=======================================================

        this.userProfileService
            .getAll()
            .subscribe(
            {
                next:
                    (
                        response:
                            any[]
                    ): void =>
                {
                    const allUserProfiles =
                    [
                        ...response
                    ];


                    this.specialAssignmentService
                        .getAll()
                        .subscribe(
                        {
                            next:
                                (
                                    assignments:
                                        any[]
                                ): void =>
                            {
                                const assignedUserProfileIds =
                                    new Set<number>
                                    (
                                        assignments
                                            .filter
                                            (
                                                assignment =>
                                                    assignment != null
                                                    &&
                                                    assignment.userProfileId != null
                                            )
                                            .map
                                            (
                                                assignment =>
                                                    Number(
                                                        assignment.userProfileId
                                                    )
                                            )
                                            .filter
                                            (
                                                id =>
                                                    id > 0
                                            )
                                    );


                                this.userProfiles =
                                    allUserProfiles.filter
                                    (
                                        userProfile =>
                                        {
                                            const userProfileId =
                                                Number(
                                                    userProfile.id
                                                    ??
                                                    userProfile.userProfileId
                                                );


                                            return userProfileId > 0
                                                &&
                                                !assignedUserProfileIds.has(
                                                    userProfileId
                                                );
                                        }
                                    );


                                this.cdr.detectChanges();
                            },


                            error:
                                (
                                    error:
                                        unknown
                                ): void =>
                            {
                                console.error
                                (
                                    'Load Special Assignments For User Profile Filter Error',

                                    error
                                );


                                // Do NOT expose already configured
                                // users if the assignment source
                                // could not be loaded.
                                this.userProfiles =
                                [
                                ];


                                this.toast.error
                                (
                                    'Load Failed',

                                    'Unable to determine already configured user profiles.'
                                );


                                this.cdr.detectChanges();
                            }
                        }
                    );
                },


                error:
                    (
                        error:
                            unknown
                    ): void =>
                {
                    console.error
                    (
                        'Load User Profiles Error',

                        error
                    );


                    this.userProfiles =
                    [
                    ];


                    this.toast.error
                    (
                        'Load Failed',

                        'Unable to load user profiles.'
                    );


                    this.cdr.detectChanges();
                }
            });
    }


    //===========================================================
    // Load All User Profiles
    //===========================================================

    private loadAllUserProfiles():
        void
    {
        this.userProfileService
            .getAll()
            .subscribe(
            {
                next:
                    (
                        response:
                            any[]
                    ): void =>
                {
                    this.userProfiles =
                    [
                        ...response
                    ];


                    this.loadModules();


                    this.cdr.detectChanges();
                },


                error:
                    (
                        error:
                            unknown
                    ): void =>
                {
                    console.error
                    (
                        'Load User Profiles Error',

                        error
                    );


                    this.userProfiles =
                    [
                    ];


                    this.toast.error
                    (
                        'Load Failed',

                        'Unable to load user profiles.'
                    );


                    this.cdr.detectChanges();
                }
            });
    }


    //===========================================================
    // Load Modules
    //===========================================================

    private loadModules():
        void
    {
        this.moduleService

            .getAll()

            .subscribe(
            {
                next:(response) =>
                {
                    this.infrastructureControlModuleIds =
                        response
                            .filter(
                                module =>
                                    this.isInfrastructureControlModule(
                                        module
                                    )
                            )
                            .map(
                                module =>
                                    Number(
                                        module.id
                                    )
                            )
                            .filter(
                                id =>
                                    id > 0
                            );


                    const availableModules =
                        response.filter(
                            module =>
                                this.isInfrastructureControlAllowed()
                                ||
                                !this.isInfrastructureControlModule(
                                    module
                                )
                        );


                    this.modules =
                    this.isInfrastructureControlAllowed()
                    ?
                    [
                        ...this.defaultModules,

                        ...availableModules
                    ]
                    :
                    [
                        ...availableModules
                    ];

                    this.cdr.detectChanges();
                },

                error:(error) =>
                {
                    console.error(error);

                    this.toast.error(
                        'Error',
                        'Failed to load modules.'
                    );
                }
            });
    }


    //===========================================================
    // Load Master Activities
    //===========================================================

    private loadMasterActivities():
        void
    {
        this.masterActivityService

            .getAll()

            .subscribe(
            {
                next:(response) =>
                {
                    this.pageActivityPages =
                        new Map(
                            response
                                .filter(activity => activity.activityScope === 'Page')
                                .map(
                                    activity =>
                                    [
                                        activity.id,
                                        new Set((activity.pageSubmenuIds ?? []).map(Number))
                                    ] as [number, Set<number>]
                                )
                        );
                    this.masterActivities =
                        response.map(
                            activity => (
                            {
                                id:
                                    activity.id,

                                text:
                                    activity.name,

                                group:
                                    activity.activityScope === 'Page'
                                        ? 'page'
                                        : 'common',

                                checked:
                                    false
                            })
                        );

                    // Fixed Page Actions slots : one per action, same column on
                    // every row, each with its own "All" box in the header.
                    this.pageSlots =
                        buildPageSlots
                        (
                            this.masterActivities.filter
                            (
                                activity =>
                                    activity.group === 'page'
                                    &&
                                    (this.pageActivityPages.get(activity.id)?.size ?? 0) > 0
                            ),
                            this.pageActivityPages
                        );

                    //===================================================
                    // Edit / View Synchronization
                    //
                    // The assignment and master activities are loaded
                    // independently. If the assignment arrives first,
                    // rebuild the cart after master activities arrive.
                    //===================================================

                    if
                    (
                        this.mode !== 'add'
                    )
                    {
                        this.editCartInitialized =
                            false;

                        this.loadMenus(
                            0
                        );
                    }

                    this.cdr.detectChanges();
                },

                error:(error) =>
                {
                    console.error(error);

                    this.toast.error(
                        'Error',
                        'Failed to load master activities.'
                    );
                }
            });
    }


    //===========================================================
    // Initialize Mode
    //===========================================================

    private initializeMode():
        void
    {
        const url =
            this.router.url;


        if
        (
            url.includes('/edit/')
        )
        {
            this.mode =
                'edit';
        }
        else if
        (
            url.includes('/view/')
        )
        {
            this.mode =
                'view';
        }
        else
        {
            this.mode =
                'add';
        }


        const id =
            this.resolveEntityId();


        if
        (
            id > 0
        )
        {
            this.specialAssignmentId =
                id;


            this.loadSpecialAssignment();
        }
        else
        {
            this.initializeDefaults();
        }
    }


    //===========================================================
    // Resolve Entity Id
    //===========================================================

    private resolveEntityId():
        number
    {
        let currentRoute:
            ActivatedRoute | null =
            this.route;


        while
        (
            currentRoute
        )
        {
            const id =
                Number(
                    currentRoute.snapshot.paramMap.get(
                        'id'
                    )
                );


            if
            (
                id > 0
            )
            {
                return id;
            }


            currentRoute =
                currentRoute.parent;
        }


        return 0;
    }


    //===========================================================
    // Initialize Defaults
    //
    // Special Assignment has no backend defaults endpoint.
    // Add mode therefore starts from the local empty master model.
    //===========================================================

    private initializeDefaults():
        void
    {
        this.specialAssignment =
        {
            specialAssignmentId:0,

            userProfileId:0,

            userProfileName:'',

            pageCount:0,

            masterActivityCount:0,

            specialActivityCount:0,

            totalActivityCount:0,

            isActive:true,

            details:[]
        };


        this.selectedUserProfileId =
            null;


        this.selectedModuleId =
            null;


        this.selectedMenuId =
            null;


        this.selectedSubMenuId =
            null;


        this.itemCartRows =
        [
        ];


        this.pagedItemCartRows =
        [
        ];


        this.originalSpecialAssignment =

            JSON.stringify(
                this.specialAssignment
            );


        this.editCartInitialized =
            false;


        this.hasChanges =
            false;


        this.cdr.detectChanges();
    }


    //===========================================================
    // Load Special Assignment
    //===========================================================

    private loadSpecialAssignment():
        void
    {
        this.loading =
            true;

        this.orbitLoading =
            true;

        this.loadFailed =
            false;

        this.specialAssignmentService

            .getById(
                this.specialAssignmentId
            )

            .subscribe(
            {
                next:(response) =>
                {
                    this.bindSpecialAssignment(
                        response
                    );

                    this.loading =
                        false;

                    //===================================================
                    // Orbit Loader
                    //
                    // The final loading state is controlled by
                    // refreshItemCartRows() after the navigation
                    // and cart data have been restored.
                    //===================================================

                    this.cdr.detectChanges();
                },

                error:(error) =>
                {
                    console.error(error);

                    this.loading =
                        false;

                    this.orbitLoading =
                        false;

                    this.loadFailed =
                        true;

                    this.toast.error(
                        'Error',
                        'Failed to load special assignment.'
                    );

                    this.cdr.detectChanges();
                }
            });
    }


    //===========================================================
    // Bind Special Assignment
    //===========================================================

    private bindSpecialAssignment
    (
        data:SpecialAssignment
    ):
        void
    {
        this.specialAssignment =
        {
            ...data,

            details:
                Array.isArray(data?.details)
                    ?
                    data.details
                    :
                    []
        };


        //=======================================================
        // Reset Edit Cart Initialization
        //
        // The first submenu load will restore the saved database
        // rows. Later selection changes must preserve the working
        // cart instead of rebuilding it.
        //=======================================================

        this.editCartInitialized =
            false;


        this.selectedUserProfileId =
            data.userProfileId;


        this.loadModules();


        //=======================================================
        // Restore Saved Navigation Selection
        //
        // IMPORTANT:
        // The saved Special Assignment contains ModuleId,
        // MenuId and SubMenuId in its detail rows.
        //
        // Previously these values were reset to null here.
        // Therefore the Edit / View dropdowns stayed blank even
        // though the database detail rows were loaded correctly.
        //
        // Restore the first saved detail as the current hierarchy
        // selection. All saved detail rows are still restored into
        // the cart below.
        //=======================================================

        const firstDetail =
            this.specialAssignment.details.length > 0
                ?
                this.specialAssignment.details[0]
                :
                null;


        this.selectedModuleId =
            firstDetail?.moduleId
            ??
            null;


        this.selectedMenuId =
            firstDetail?.menuId
            ??
            null;


        this.selectedSubMenuId =
            firstDetail?.subMenuId
            ??
            null;


        //=======================================================
        // Load Complete Navigation Data
        //
        // Use All Menus / All Sub Menus during Edit / View
        // restoration so every saved detail row can resolve its
        // Menu and Sub Menu name, including rows from different
        // menus or modules.
        //=======================================================

        this.loadMenus(
            0
        );


        this.originalSpecialAssignment =

            JSON.stringify(
                data
            );


        this.updateHeaderCheckboxStates();

        this.updateUserProfileLock();
    }


    //===========================================================
    // Apply Existing Permissions To Cart
    //===========================================================

    private applyPermissionsToCart():
        void
    {
        this.itemCartRows.forEach(
            row =>
            {
                const existingPermissions =

                    this.getExistingPermissions(
                        row.subMenuId
                    );


                row.masterActivities.forEach(
                    activity =>
                    {
                        activity.checked =

                            existingPermissions.some(
                                permission =>
                                    Number(
                                        permission.masterActivityId
                                    )
                                    ===
                                    Number(
                                        activity.id
                                    )
                            );
                    });

            });


        this.updatePagination();

        this.updateHeaderCheckboxStates();

        this.cdr.detectChanges();
    }


    //===========================================================
    // Detect Changes
    //===========================================================

    private detectChanges():
        void
    {
        this.hasChanges =

            JSON.stringify(
                this.specialAssignment
            )
            !==
            this.originalSpecialAssignment;
    }


    //===========================================================
    // User Profile Changed
    //===========================================================

    onUserProfileChanged
    (
        value:number | null
    ):
        void
    {
        this.selectedUserProfileId =
            value;


        this.isAddDisabled =
            this.selectedUserProfileId == null;


        if
        (
            this.selectedUserProfileId
        )
        {
            this.specialAssignment.userProfileId =
                this.selectedUserProfileId;
        }


        this.loadModules();


        if
        (
            this.selectedModuleId != null
            &&
            !this.isInfrastructureControlAllowed()
            &&
            this.isInfrastructureControlModuleId(
                this.selectedModuleId
            )
        )
        {
            this.selectedModuleId =
                null;

            this.selectedMenuId =
                null;

            this.selectedSubMenuId =
                null;

            this.menus =
            [
                ...this.defaultMenus
            ];

            this.subMenus =
            [
                ...this.defaultSubMenus
            ];

            this.isAddDisabled =
                true;
        }


        this.detectChanges();
    }


    //===========================================================
    // Module Changed
    //===========================================================

    onModuleChanged
    (
        value:number | null
    ):
        void
    {
        if
        (
            value != null
            &&
            !this.isInfrastructureControlAllowed()
            &&
            this.isInfrastructureControlModuleId(
                value
            )
        )
        {
            this.toast.warning(
                'Access Restricted',
                'Infrastructure Control is reserved for User Profile RP001.'
            );

            this.selectedModuleId =
                null;

            this.selectedMenuId =
                null;

            this.selectedSubMenuId =
                null;

            this.isAddDisabled =
                true;

            return;
        }


        this.selectedModuleId =
            value;

        this.selectedMenuId =
            null;

        this.selectedSubMenuId =
            null;

        this.menus =
        [
            ...this.defaultMenus
        ];

        this.subMenus =
        [
            ...this.defaultSubMenus
        ];


        //=======================================================
        // Nothing Selected
        //=======================================================

        if
        (
            value == null
        )
        {
            this.isAddDisabled =
                true;

            return;
        }


        //=======================================================
        // All Modules
        //=======================================================

        if
        (
            value === 0
        )
        {
            this.selectedMenuId =
                0;

            this.selectedSubMenuId =
                0;

            this.loadMenus(
                0
            );

            this.loadSubMenus(
                0
            );

            this.isAddDisabled =
                false;

            return;
        }


        //=======================================================
        // Specific Module
        //=======================================================

        this.selectedMenuId =
            0;

        this.selectedSubMenuId =
            0;

        this.loadMenus(
            value
        );

        this.loadSubMenus(
            0
        );

        this.isAddDisabled =
            false;
    }


    //===========================================================
    // Load Menus
    //===========================================================

    private loadMenus
    (
        moduleId:number
    ):
        void
    {
        const request =

            moduleId === 0
            ?
            this.menuService.getAll()
            :
            this.menuService.getByModule(
                moduleId
            );


        request.subscribe(
        {
            next:(response:any[]) =>
            {
                this.menus =
                [
                    ...this.defaultMenus,

                    ...response
                ];


                //===================================================
                // Edit / View Navigation Restoration
                //
                // Keep the saved Menu / Sub Menu selections.
                // The existing assignment detail rows contain the
                // actual navigation IDs and are restored separately
                // by refreshItemCartRows().
                //===================================================

                if
                (
                    this.mode !== 'add'
                )
                {
                    this.loadSubMenus(
                        0
                    );

                    return;
                }


                this.cdr.detectChanges();
            },


            error:(error:any) =>
            {
                console.error(error);


                this.toast.error(
                    'Error',
                    'Failed to load menus.'
                );
            }
        });
    }


    //===========================================================
    // Menu Changed
    //===========================================================

    onMenuChanged
    (
        value:number | null
    ):
        void
    {
        this.selectedMenuId =
            value;

        this.selectedSubMenuId =
            null;

        this.subMenus =
        [
            ...this.defaultSubMenus
        ];


        //=======================================================
        // Nothing Selected
        //=======================================================

        if
        (
            value == null
        )
        {
            this.isAddDisabled =
                true;

            return;
        }


        //=======================================================
        // All Menus
        //=======================================================

        if
        (
            value === 0
        )
        {
            this.selectedSubMenuId =
                0;

            this.loadSubMenus(
                0
            );

            this.isAddDisabled =
                false;

            return;
        }


        //=======================================================
        // Specific Menu
        //=======================================================

        this.selectedSubMenuId =
            0;

        this.loadSubMenus(
            value
        );

        this.isAddDisabled =
            false;
    }


    //===========================================================
    // Load Sub Menus
    //===========================================================

    private loadSubMenus
    (
        menuId:number
    ):
        void
    {
        const request =

            menuId === 0
            ?
            this.submenuService.getAll()
            :
            this.submenuService.getByMenu(
                menuId
            );


        request.subscribe(
        {
            next:(response:any[]) =>
            {
                //===================================================
                // Filter All Sub Menus By Selected Module
                //
                // During the first Edit / View restoration we must
                // keep ALL sub menus available because the saved
                // assignment may contain rows from more than one
                // module.
                //
                // Normal Add-mode filtering remains unchanged.
                //===================================================

                let filteredResponse =
                    response;


                const restoringExistingAssignment =
                    this.mode !== 'add'
                    &&
                    !this.editCartInitialized;


                if
                (
                    !restoringExistingAssignment
                    &&
                    menuId === 0
                    &&
                    this.selectedModuleId != null
                    &&
                    this.selectedModuleId !== 0
                )
                {
                    filteredResponse =
                        response.filter(
                            subMenu =>
                                Number(
                                    subMenu?.navigationModuleId
                                )
                                ===
                                Number(
                                    this.selectedModuleId
                                )
                        );
                }


                this.subMenus =
                [
                    ...this.defaultSubMenus,

                    ...filteredResponse
                ];


                //===================================================
                // Restore Item Cart During Edit/View — ONCE ONLY
                //
                // IMPORTANT:
                // Previously this ran on EVERY Module/Menu/Sub Menu
                // change in Edit mode. That rebuilt itemCartRows from
                // the original database data and therefore removed
                // rows that had just been added during the same edit
                // session.
                //
                // Now the saved rows are restored only on the first
                // submenu load. All later selections work against
                // the existing itemCartRows and therefore APPEND.
                //===================================================

                if
                (
                    this.mode !== 'add'
                    &&
                    !this.editCartInitialized
                )
                {
                    this.editCartInitialized =
                        true;


                    this.refreshItemCartRows();

                    this.applyPermissionsToCart();

                    this.cdr.detectChanges();

                    return;
                }


                this.cdr.detectChanges();
            },


            error:(error:any) =>
            {
                console.error(error);


                this.toast.error(
                    'Error',
                    'Failed to load sub menus.'
                );
            }
        });
    }


    //===========================================================
    // Sub Menu Changed
    //===========================================================

    onSubMenuChanged
    (
        value:number | null
    ):
        void
    {
        this.selectedSubMenuId =
            value;
    }


    //===========================================================
    // Get Menu Name
    //
    // Existing Special Assignment responses may contain only the
    // navigation IDs. Resolve the display name from the loaded
    // Menu collection instead of depending on menuName being
    // returned by the API.
    //===========================================================

    private getMenuName
    (
        menuId:number
    ):
        string
    {
        const id =
            Number(
                menuId
            );


        if
        (
            id <= 0
        )
        {
            return '';
        }


        const menu =
            this.menus.find(
                item =>
                    Number(
                        item?.id
                        ??
                        item?.menuId
                        ??
                        item?.navigationMenuId
                        ??
                        item?.MenuId
                    )
                    ===
                    id
            );


        return (
            menu?.name
            ??
            menu?.menuName
            ??
            menu?.navigationMenuName
            ??
            menu?.text
            ??
            menu?.title
            ??
            ''
        );
    }



    //===========================================================
    // Get Sub Menu Name
    //
    // Existing Special Assignment responses may contain only the
    // navigation IDs. Resolve the display name from the loaded
    // Sub Menu collection instead of depending on subMenuName
    // being returned by the API.
    //===========================================================

    private getSubMenuName
    (
        subMenuId:number
    ):
        string
    {
        const id =
            Number(
                subMenuId
            );


        if
        (
            id <= 0
        )
        {
            return '';
        }


        const subMenu =
            this.subMenus.find(
                item =>
                    Number(
                        item?.id
                        ??
                        item?.subMenuId
                        ??
                        item?.navigationSubmenuId
                        ??
                        item?.navigationSubMenuId
                        ??
                        item?.SubMenuId
                    )
                    ===
                    id
            );


        return (
            subMenu?.name
            ??
            subMenu?.subMenuName
            ??
            subMenu?.navigationSubMenuName
            ??
            subMenu?.text
            ??
            subMenu?.title
            ??
            ''
        );
    }


    //===========================================================
    // Refresh Item Cart Rows
    //===========================================================

    private refreshItemCartRows():
        void
    {
        //=======================================================
        // Edit / View Mode
        //
        // Edit / View must ALWAYS use the saved assignment
        // details as the source of truth, including when the
        // assignment contains zero rows.
        //=======================================================

        if
        (
            this.mode !== 'add'
        )
        {
            this.pendingActivityLoads =
                this.specialAssignment.details.length;

            this.completedActivityLoads =
                this.specialAssignment.details.length;

            this.itemCartRows =

                this.specialAssignment.details.map(
                    detail =>
                    {
                        const existingPermissions =

                            this.getExistingPermissions(
                                detail.subMenuId
                            );

                        const row:ItemCartRow =
                        {
                            id:
                                detail.subMenuId,

                            roleProfileId:
                                this.selectedUserProfileId
                                ??
                                0,

                            moduleId:
                                detail.moduleId,

                            menuId:
                                detail.menuId,

                            subMenuId:
                                detail.subMenuId,

                            menu:
                                (
                                    detail.menuName
                                    ??
                                    this.getMenuName(
                                        detail.menuId
                                    )
                                )
                                ||
                                '',

                            subMenu:
                                (
                                    detail.subMenuName
                                    ??
                                    this.getSubMenuName(
                                        detail.subMenuId
                                    )
                                )
                                ||
                                '',

                            masterActivities:

                                this.activitiesFor(detail.subMenuId).map(
                                    activity =>
                                    ({
                                        id:
                                            activity.id,

                                        text:
                                            activity.text,
                                        group:
                                            activity.group,

                                        checked:

                                            existingPermissions.some(
                                                permission =>
                                                    permission.masterActivityId ===
                                                    activity.id
                                            )
                                    })
                                ),
                        };

                        return row;
                    }
                );

            this.updatePagination();

            this.updateHeaderCheckboxStates();

            this.orbitLoading =
                false;

            this.loading =
                false;

            this.cdr.detectChanges();

            return;
        }

        //=======================================================
        // Add Mode
        //=======================================================

        if
        (
            this.subMenus.length === 0
        )
        {
            this.itemCartRows =
            [
            ];

            this.updatePagination();

            this.orbitLoading =
                false;

            this.loading =
                false;

            this.cdr.detectChanges();

            return;
        }

        this.itemCartRows =

            this.subMenus

                .filter(
                    subMenu =>

                        subMenu.id === 0
                        ||
                        !this.selectedSubMenuId
                        ||
                        subMenu.id === this.selectedSubMenuId
                )

                .map(
                    subMenu =>
                    {
                        const existingPermissions =

                            this.getExistingPermissions(
                                subMenu.id
                            );

                        const row:ItemCartRow =
                        {
                            id:
                                subMenu.id,

                            roleProfileId:
                                this.selectedUserProfileId
                                ??
                                0,

                            moduleId:
                                this.selectedModuleId
                                ??
                                0,

                            menuId:
                                this.selectedMenuId
                                ??
                                0,

                            subMenuId:
                                subMenu.id,

                            menu:
                                subMenu.menuName
                                ??
                                '',

                            subMenu:
                                subMenu.name,

                            masterActivities:

                                this.activitiesFor(subMenu.id).map(
                                    activity =>
                                    ({
                                        id:
                                            activity.id,

                                        text:
                                            activity.text,
                                        group:
                                            activity.group,

                                        checked:

                                            existingPermissions.some(
                                                permission =>
                                                    permission.masterActivityId ===
                                                    activity.id
                                            )
                                    })
                                ),
                        };

                        return row;
                    }
                );

        this.updatePagination();

        this.updateHeaderCheckboxStates();

        this.orbitLoading =
            false;

        this.loading =
            false;

        this.cdr.detectChanges();
    }

    //===========================================================
    // Get Existing Permissions
    //===========================================================

    private getExistingPermissions
    (
        subMenuId:number
    ):
        SpecialAssignmentPermission[]
    {
        const details =
            this.specialAssignment?.details
            ??
            [];


        const detail =
            details.find
            (
                x =>
                    Number(
                        x.subMenuId
                    )
                    ===
                    Number(
                        subMenuId
                    )
            );


        if
        (
            !detail
        )
        {
            return [];
        }


        return detail.specialAssignmentPermissions ?? [];
    }


    //===========================================================
    // Build Permission Rows
    //===========================================================

    private buildPermissionRows
    (
        existingPermissions:
            SpecialAssignmentPermission[]
    ):
        any[]
    {
        return this.masterActivities.map(
            activity =>
            ({
                specialAssignmentPermissionId:
                    0,

                masterActivityId:
                    activity.id,

                activityName:
                    activity.text,

                checked:
                    existingPermissions.some(
                        permission =>
                            permission.masterActivityId ===
                            activity.id
                    )
            })
        );
    }


    //===========================================================
    // Build Special Assignment Payload
    //===========================================================

    private buildSpecialAssignment():
        SpecialAssignmentSavePayload
    {
        const details:
            SpecialAssignmentSaveDetail[] =
            [];


        this.itemCartRows.forEach(
            row =>
            {
                const permissions:
                    SpecialAssignmentSavePermission[] =

                    row.masterActivities

                        .map(
                            permission =>
                            ({
                                masterActivityId:
                                    permission.checked
                                    ?
                                    permission.id
                                    :
                                    null,

                                navigationActivityId:
                                    null,

                                isActive:true
                            })
                        )

                        .filter(
                            permission =>
                                permission.masterActivityId !== null
                        );


                if
                (
                    permissions.length > 0
                )
                {
                    details.push(
                    {
                        specialAssignmentDetailId:
                            this.getExistingDetailId(
                                row.subMenuId
                            ),

                        specialAssignmentId:
                            this.specialAssignment.specialAssignmentId,

                        moduleId:
                            row.moduleId,

                        menuId:
                            row.menuId,

                        subMenuId:
                            row.subMenuId,

                        permissions:

                            permissions,

                        isActive:true
                    });
                }
            }
        );


        const payload:
            SpecialAssignmentSavePayload =
        {
            specialAssignmentId:

                this.specialAssignment.specialAssignmentId,

            userProfileId:

                this.selectedUserProfileId
                ??
                0,

            isActive:

                this.specialAssignment.isActive,

            details
        };


        return payload;
    }


    //===========================================================
    // Get Existing Detail Id
    //===========================================================

    private getExistingDetailId
    (
        subMenuId:number
    ):
        number | undefined
    {
        const detail =
            this.specialAssignment.details.find(
                x =>
                    x.subMenuId ===
                    subMenuId
            );


        return detail?.specialAssignmentDetailId;
    }


    //===========================================================
    // Master Activity Count
    //===========================================================

    private getMasterActivityCount():
        number
    {
        return this.itemCartRows

            .flatMap(
                row =>
                    row.masterActivities
            )

            .filter(
                activity =>

                    activity.checked
            )

            .length;
    }


    //===========================================================
    // Save
    //===========================================================

    save():
        void
    {
        const payload =

            this.buildSpecialAssignment();


        if
        (
            this.mode === 'add'
        )
        {
            this.create(
                payload
            );
        }
        else
        {
            this.update(
                payload
            );
        }
    }


    //===========================================================
    // Create
    //===========================================================

    private create
    (
        payload:SpecialAssignmentSavePayload
    ):
        void
    {
        this.progressDialog.show(
            'Saving Special Assignment',
            'Preparing data...',
            false
        );


        this.progressDialog.update(
            20,
            'Preparing data...'
        );


        setTimeout(
            () =>
            {
                this.progressDialog.update(
                    60,
                    'Saving special assignment...'
                );


                this.specialAssignmentService

                    .create(
                        payload
                    )

                    .subscribe(
                    {
                        next:() =>
                        {
                            this.progressDialog.update(
                                100,
                                'Finalizing...'
                            );


                            setTimeout(
                                () =>
                                {
                                    this.progressDialog.close();


                                    this.toast.success(
                                        'Success',
                                        'Special Assignment created successfully.'
                                    );


                                    this.hasChanges =
                                        false;


                                    void this.router.navigate(
                                    [
                                        '/security-permission/user-management/special-assignment/list'
                                    ]);
                                },
                                400
                            );
                        },


                        error:(error) =>
                        {
                            this.progressDialog.close();


                            console.error(error);


                            this.toast.error(
                                'Error',
                                'Failed to create special assignment.'
                            );
                        }
                    });
            },
            300
        );
    }


    //===========================================================
    // Update
    //===========================================================

    private update
    (
        payload:SpecialAssignmentSavePayload
    ):
        void
    {
        this.progressDialog.show(
            'Updating Special Assignment',
            'Preparing data...',
            false
        );


        this.progressDialog.update(
            20,
            'Preparing data...'
        );


        setTimeout(
            () =>
            {
                this.progressDialog.update(
                    60,
                    'Updating special assignment...'
                );


                this.specialAssignmentService

                    .update(
                        payload
                    )

                    .subscribe(
                    {
                        next:() =>
                        {
                            this.progressDialog.update(
                                100,
                                'Finalizing...'
                            );


                            setTimeout(
                                () =>
                                {
                                    this.progressDialog.close();


                                    this.toast.success(
                                        'Success',
                                        'Special Assignment updated successfully.'
                                    );


                                    this.hasChanges =
                                        false;


                                    void this.router.navigate(
                                    [
                                        '/security-permission/user-management/special-assignment/list'
                                    ]);
                                },
                                400
                            );
                        },


                        error:(error) =>
                        {
                            this.progressDialog.close();


                            console.error(error);


                            this.toast.error(
                                'Error',
                                'Failed to update special assignment.'
                            );
                        }
                    });
            },
            300
        );
    }


    //===========================================================
    // Delete
    //===========================================================

    delete():
        void
    {
        this.confirmDialog.open(

            'Delete Special Assignment',

            'Are you sure you want to delete this special assignment?',


            () =>
            {
                this.specialAssignmentService

                    .delete(
                        this.specialAssignmentId
                    )

                    .subscribe(
                    {
                        next:() =>
                        {
                            this.toast.success(
                                'Deleted',
                                'Special Assignment deleted successfully.'
                            );


                            this.router.navigate(
                            [
                                '/security-permission/user-management/special-assignment/list'
                            ]);
                        },


                        error:(error) =>
                        {
                            console.error(error);


                            this.toast.error(
                                'Error',
                                'Failed to delete special assignment.'
                            );
                        }
                    });
            }
        );
    }


    //===========================================================
    // Restore
    //===========================================================

    restore():
        void
    {
        this.confirmDialog.open(

            'Restore Special Assignment',

            'Are you sure you want to restore the most recently deleted special assignment.',


            () =>
            {
                this.specialAssignmentService

                    .restore()

                    .subscribe(
                    {
                        next:() =>
                        {
                            this.toast.success(
                                'Restore Successful',

                                'The most recently deleted special assignment has been restored.'
                            );


                            this.loadSpecialAssignment();
                        },


                        error:(error) =>
                        {
                            console.error(
                                'Restore Special Assignment Error:',

                                error
                            );


                            this.toast.error(
                                'Restore Failed',

                                'Failed to restore special assignment.'
                            );
                        }
                    });
            }
        );
    }

    //===========================================================
    // Cancel
    //===========================================================

    cancel():
        void
    {
        this.router.navigate(
        [
            '/security-permission/user-management/special-assignment/list'
        ]);
    }


    //===========================================================
    // Clear
    //===========================================================

    clear():
        void
    {
        this.activitySearchText =
            '';


        this.currentPage =
            1;


        this.selectedModuleId =
            null;


        this.selectedMenuId =
            null;


        this.selectedSubMenuId =
            null;


        this.itemCartRows =
        [
        ];


        //=======================================================
        // Update User Profile Lock
        //=======================================================

        this.updateUserProfileLock();


        this.updatePagination();

        this.updateHeaderCheckboxStates();

        this.cdr.detectChanges();
    }


    //===========================================================
    // Update User Profile Lock
    //===========================================================

    private updateUserProfileLock():
        void
    {
        this.isUserProfileLocked =
            this.mode !== 'add'
            ||
            this.itemCartRows.length > 0;
    }


    //===========================================================
    // View Mode
    //===========================================================

    get isViewMode():
        boolean
    {
        return this.mode === 'view';
    }


    //===========================================================
    // Check Permission
    //===========================================================

    isPermissionChecked
    (
        permission:any
    ):
        boolean
    {
        return permission.checked === true;
    }


    //===========================================================
    // Toggle Permission
    //===========================================================

    togglePermission
    (
        permission:any
    ):
        void
    {
        if
        (
            this.isViewMode
        )
        {
            return;
        }


        permission.checked =
            !permission.checked;


        this.updateHeaderCheckboxStates();


        this.detectChanges();
    }


    //===========================================================
    // Build Selected Rows
    //===========================================================

    private buildSelectedRows():
        ItemCartRow[]
    {
        let selectedSubMenus =
            this.subMenus;


        //=======================================================
        // Remove Default Item
        //=======================================================

        selectedSubMenus =
            selectedSubMenus.filter(
                subMenu =>
                    subMenu.id > 0
            );


        if
        (
            !this.isInfrastructureControlAllowed()
        )
        {
            selectedSubMenus =
                selectedSubMenus.filter(
                    subMenu =>
                        !this.isInfrastructureControlModuleId(
                            subMenu?.navigationModuleId
                        )
                );
        }


        //=======================================================
        // Specific Sub Menu Selected
        //=======================================================

        if
        (
            this.selectedSubMenuId != null
            &&
            this.selectedSubMenuId > 0
        )
        {
            selectedSubMenus =
                selectedSubMenus.filter(
                    subMenu =>
                        subMenu.id ===
                        this.selectedSubMenuId
                );
        }


        //=======================================================
        // Build Cart Rows
        //=======================================================

        const rows:ItemCartRow[] =

            selectedSubMenus.map(
                subMenu =>
                ({
                    //===================================================
                    // Use the real submenu id as the row id
                    //===================================================

                    id:
                        subMenu.id,


                    roleProfileId:
                        this.selectedUserProfileId ?? 0,


                    moduleId:
                        subMenu.navigationModuleId,


                    menuId:
                        subMenu.navigationMenuId,


                    subMenuId:
                        subMenu.id,


                    menu:
                        subMenu.navigationMenuName,


                    subMenu:
                        subMenu.name,


                    masterActivities:

                        this.activitiesFor(subMenu.id).map(
                            activity =>
                            ({
                                id:
                                    activity.id,

                                text:
                                    activity.text,
                                group:
                                    activity.group,

                                checked:
                                    false
                            })
                        ),
                })
            );


        return rows;
    }


    //===========================================================
    // Add Selection
    //===========================================================

    onAddSelection():
        void
    {
        if
        (
            this.selectedUserProfileId == null
        )
        {
            return;
        }


        const selectedSubMenus =

            this.buildSelectedRows();


        if
        (
            !this.isInfrastructureControlAllowed()
            &&
            selectedSubMenus.some(
                row =>
                    this.isInfrastructureControlModuleId(
                        row.moduleId
                    )
            )
        )
        {
            this.toast.warning(
                'Access Restricted',
                'Infrastructure Control is reserved for User Profile RP001.'
            );

            return;
        }


        let duplicateFound =
            false;


        let addedCount =
            0;


        selectedSubMenus.forEach(
            row =>
            {
                const exists =

                    this.itemCartRows.some(
                        item =>
                            item.subMenuId === row.subMenuId
                    );


                if
                (
                    exists
                )
                {
                    duplicateFound =
                        true;

                    return;
                }


                this.itemCartRows.push(
                    row
                );


                addedCount++;
            }
        );


        //=======================================================
        // Duplicate Validation Toast
        //=======================================================

        if
        (
            duplicateFound
        )
        {
            this.toast.warning(
                'Already Added',
                'One or more selected sub menus are already added in the cart.'
            );
        }


        //=======================================================
        // Update User Profile Lock
        //=======================================================

        this.updateUserProfileLock();


        this.updatePagination();

        this.updateHeaderCheckboxStates();

        this.cdr.detectChanges();
    }


    //===========================================================
    // Reset Selection
    //===========================================================

    onResetSelection():
        void
    {
        this.itemCartRows =
            this.itemCartRows.map(
                row =>
                ({
                    ...row,

                    masterActivities:
                        row.masterActivities.map(
                            activity =>
                            ({
                                ...activity,

                                checked:false
                            })
                        ),
                })
            );


        this.headerCheckboxStates =
        {
            all:false,
            view:false,
            add:false,
            update:false,
            delete:false,
            restore:false
        };


        this.updateUserProfileLock();

        this.updatePagination();

        this.detectChanges();

        this.cdr.detectChanges();
    }


    //===========================================================
    // Save Command
    //===========================================================
    onSave():
        void
    {
        if
        (
            this.isViewMode
        )
        {
            return;
        }
        if
        (
            this.selectedUserProfileId == null
        )
        {
            this.toast.error(
                'Validation',
                'User Profile is required.'
            );
            return;
        }


        if
        (
            !this.isInfrastructureControlAllowed()
            &&
            this.containsInfrastructureControlRow()
        )
        {
            this.toast.error(
                'Access Restricted',
                'Infrastructure Control is reserved for User Profile RP001.'
            );

            return;
        }


        if
        (
            this.mode === 'add'
            &&
            this.itemCartRows.length === 0
        )
        {
            this.toast.error(
                'Validation',
                'At least one submenu assignment is required.'
            );
            return;
        }
        this.save();
    }

    //===========================================================
    // Clear Command
    //===========================================================

    onClear():
        void
    {
        if
        (
            this.isViewMode
        )
        {
            return;
        }


        this.clear();
    }


    //===========================================================
    // Back To List
    //===========================================================

    onBackToList():
        void
    {
        this.router.navigate(
        [
            '/security-permission/user-management/special-assignment/list'
        ]);
    }


    //===========================================================
    // Back
    //===========================================================

    back():
        void
    {
        this.router.navigate(
        [
            '/security-permission/user-management/special-assignment/list'
        ]);
    }


    //===========================================================
    // Save Disabled
    //===========================================================

    get saveDisabled():
        boolean
    {
        return (
            this.isViewMode
            ||
            this.selectedUserProfileId == null
            ||
            (
                this.mode === 'add'
                &&
                this.itemCartRows.length === 0
            )
        );
    }


    //===========================================================
    // Add Disabled
    //===========================================================

    get addDisabled():
        boolean
    {
        return (

            this.isViewMode

            ||

            this.selectedUserProfileId == null

            ||

            this.selectedModuleId == null

            ||

            this.selectedMenuId == null

            ||

            this.selectedSubMenuId == null

        );
    }


    //===========================================================
    // Total Selected Permissions
    //===========================================================

    get selectedPermissionCount():
        number
    {
        return this.itemCartRows

            .flatMap(
                row =>
                row.masterActivities
            )

            .filter(
                activity =>
                    activity.checked
            )

            .length;
    }


    //===========================================================
    // Record Counter
    //===========================================================

    get recordCounterSections():
        RecordCounterSection[]
    {
        return [

            {
                label:'Submenus',

                value:this.getFilteredItemCartRows().length
            },

            {
                label:'Activity',

                value:this.getMasterActivityCount()
            }
        ];
    }

}