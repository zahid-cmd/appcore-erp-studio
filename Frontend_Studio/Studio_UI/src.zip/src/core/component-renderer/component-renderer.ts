//===============================================================
// Imports
//===============================================================

import
{
    ChangeDetectorRef,
    Component,
    ComponentRef,
    Input,
    OnChanges,
    SimpleChanges,
    Type,
    ViewChild,
    ViewContainerRef
}
from '@angular/core';


//===============================================================
// Core Components
//===============================================================

import
{
    LoginPageBackgroundComponent
}
from '../../shared/components/core-components/background/background';

import
{
    LoginPageBrandingComponent
}
from '../../shared/components/core-components/branding/branding';

import
{
    LoginPageClientLogoComponent
}
from '../../shared/components/core-components/client-logo/client-logo';

import
{
    ConfirmationDialogComponent
}
from '../../shared/components/core-components/confirmation-dialog/confirmation-dialog';

import
{
    ChangePasswordComponent
}
from '../../shared/components/core-components/change-password/change-password';

import
{
    LoginPageFooterComponent
}
from '../../shared/components/core-components/footer/footer';

import
{
    LoginPageForgetPasswordPanelComponent
}
from '../../shared/components/core-components/forget-password/forget-password';

import
{
    LoginPageLoginPanelComponent
}
from '../../shared/components/core-components/login-panel/login-panel';

import
{
    LoginPageNotificationPanelComponent
}
from '../../shared/components/core-components/notification-panel/notification-panel';

import
{
    LoginPagePoweredByComponent
}
from '../../shared/components/core-components/powered-by/powered-by';

import
{
    LoginPageRegistrationPanelComponent
}
from '../../shared/components/core-components/registration-panel/registration-panel';

import
{
    LoginPageThemeSelectorComponent
}
from '../../shared/components/core-components/theme-selector/theme-selector';


//===============================================================
// Default Dashboard Components
//===============================================================

import
{
    WelcomeWidgetComponent
}
from '../../shared/components/default-dashboard/welcome-widget/welcome-widget';

import
{
    QuickAccessWidgetComponent
}
from '../../shared/components/default-dashboard/quick-access-widget/quick-access-widget';


//===============================================================
// Control Components
//===============================================================

import
{
    CalendarComponent
}
from '../../shared/components/controls/calendar/calendar';

import
{
    ControlTabsComponent
}
from '../../shared/components/controls/control-tabs/control-tabs';

import
{
    DatepickerComponent
}
from '../../shared/components/controls/datepicker/datepicker';

import
{
    DropdownComponent
}
from '../../shared/components/controls/dropdown/dropdown';

import
{
    ImageHubComponent
}
from '../../shared/components/controls/image-hub/image-hub';

import
{
    OverlayComponent
}
from '../../shared/components/controls/overlay/overlay';

import
{
    PaginationComponent
}
from '../../shared/components/controls/pagination/pagination';

import
{
    SearchDropdownComponent
}
from '../../shared/components/controls/search-dropdown/search-dropdown';

import
{
    TextareaComponent
}
from '../../shared/components/controls/textarea/textarea';

import
{
    TextboxComponent
}
from '../../shared/components/controls/textbox/textbox';


//===============================================================
// Layout Components
//===============================================================

import
{
    BreadcrumbComponent
}
from '../../shared/components/layout/breadcrumb/breadcrumb';

import
{
    EmptyStateComponent
}
from '../../shared/components/layout/empty-state/empty-state';

import
{
    FooterBrandComponent
}
from '../../shared/components/layout/footer-brand/footer-brand';

import
{
    FooterVersionComponent
}
from '../../shared/components/layout/footer-version/footer-version';

import
{
    FormGridComponent
}
from '../../shared/components/layout/form-grid/form-grid';

import
{
    FormSectionComponent
}
from '../../shared/components/layout/form-section/form-section';

import
{
    InlineSelectionComponent
}
from '../../shared/components/layout/inline-selection/inline-selection';

import
{
    ItemCart
}
from '../../shared/components/layout/item-cart/item-cart';

import
{
    ListTableComponent
}
from '../../shared/components/layout/list-table/list-table';

import
{
    PageCanvasComponent
}
from '../../shared/components/layout/page-canvas/page-canvas';

import
{
    PageHeaderComponent
}
from '../../shared/components/layout/page-header/page-header';

import
{
    PageToolbarComponent
}
from '../../shared/components/layout/page-toolbar/page-toolbar';

import
{
    SelectionPanelComponent
}
from '../../shared/components/layout/selection-panel/selection-panel';

import
{
    SidebarFooterComponent
}
from '../../shared/components/layout/sidebar-footer/sidebar-footer';

import
{
    TopbarActionsComponent
}
from '../../shared/components/layout/topbar-actions/topbar-actions';

import
{
    TopbarHeaderComponent
}
from '../../shared/components/layout/topbar-header/topbar-header';


//===============================================================
// Utility Components
//===============================================================

import
{
    ActivitySelector
}
from '../../shared/components/utilities/activity-selector/activity-selector';

import
{
    CheckboxComponent
}
from '../../shared/components/utilities/checkbox/checkbox';

import
{
    CommandCenterComponent
}
from '../../shared/components/utilities/command-center/command-center';

import
{
    ConfirmDialogComponent
}
from '../../shared/components/utilities/confirm-dialog/confirm-dialog';

import
{
    ControlSegmentComponent
}
from '../../shared/components/utilities/control-segment/control-segment';

import
{
    GitMessageModalComponent
}
from '../../shared/components/utilities/git-message-modal/git-message-modal';

import
{
    HistoryDrawerComponent
}
from '../../shared/components/utilities/history-drawer/history-drawer';

import
{
    OrbitLoaderComponent
}
from '../../shared/components/utilities/orbit-loader/orbit-loader';

import
{
    ProgressDialogComponent
}
from '../../shared/components/utilities/progress-dialog/progress-dialog';

import
{
    RecordCounterComponent
}
from '../../shared/components/utilities/record-counter/record-counter';

import
{
    SearchBoxComponent
}
from '../../shared/components/utilities/search-box/search-box';

import
{
    ToastComponent
}
from '../../shared/components/utilities/toast/toast';


//===============================================================
// Sub-ordinate Components
//===============================================================

import
{
    BackgroundImageComponent
}
from '../../shared/components/sub-ordinate-components/background-image-1/background-image-1';

import
{
    BackgroundImageComponent as BackgroundImageComponent2
}
from '../../shared/components/sub-ordinate-components/background-image-2/background-image-2';

import
{
    BackgroundImageComponent as BackgroundImageComponent3
}
from '../../shared/components/sub-ordinate-components/background-image-3/background-image-3';

import
{
    BackgroundImageComponent as BackgroundImageComponent4
}
from '../../shared/components/sub-ordinate-components/background-image-4/background-image-4';

import
{
    BackgroundImageComponent as BackgroundImageComponent5
}
from '../../shared/components/sub-ordinate-components/background-image-5/background-image-5';


//===============================================================
// Component
//===============================================================

@Component
({
    selector:
        'app-component-renderer',

    standalone:
        true,

    templateUrl:
        './component-renderer.html',

    styleUrl:
        './component-renderer.css'
})


export class ComponentRenderer
implements
    OnChanges
{

    //===========================================================
    // Component Host
    //===========================================================

    @ViewChild
    (
        'componentHost',
        {
            read:
                ViewContainerRef,

            static:
                true
        }
    )
    private componentHost!:
        ViewContainerRef;


    //===========================================================
    // Component Key
    //===========================================================

    @Input()
    componentKey:
        string =
        '';


    //===========================================================
    // Light Background Image URL
    //===========================================================

    @Input()
    lightBackgroundImageUrl:
        string =
        '';


    //===========================================================
    // Deep Background Image URL
    //===========================================================

    @Input()
    deepBackgroundImageUrl:
        string =
        '';


    //===========================================================
    // Component Reference
    //===========================================================

    private componentRef:
        ComponentRef<unknown>
        |
        null =
        null;


    //===========================================================
    // Dependency Injection
    //===========================================================

    constructor
    (
        private readonly cdr:
            ChangeDetectorRef
    )
    {
    }


    //===========================================================
    // Component Registry
    //===========================================================

    private readonly componentRegistry:
        Record<string, Type<unknown>>
    =
    {

        //=======================================================
        // Core Components
        //=======================================================

        'background':
            LoginPageBackgroundComponent,

        'branding':
            LoginPageBrandingComponent,

        'client-logo':
            LoginPageClientLogoComponent,

        'confirmation-dialog':
            ConfirmationDialogComponent,

        'change-password':
            ChangePasswordComponent,

        'footer':
            LoginPageFooterComponent,

        'forget-password':
            LoginPageForgetPasswordPanelComponent,

        'login-panel':
            LoginPageLoginPanelComponent,

        'notification-panel':
            LoginPageNotificationPanelComponent,

        'powered-by':
            LoginPagePoweredByComponent,

        'registration-panel':
            LoginPageRegistrationPanelComponent,

        'theme-selector':
            LoginPageThemeSelectorComponent,


        //=======================================================
        // Default Dashboard Components
        //=======================================================

        'welcome-widget':
            WelcomeWidgetComponent,

        'quick-access-widget':
            QuickAccessWidgetComponent,


        //=======================================================
        // Control Components
        //=======================================================

        'calendar':
            CalendarComponent,

        'control-tabs':
            ControlTabsComponent,

        'datepicker':
            DatepickerComponent,

        'dropdown':
            DropdownComponent,

        'image-hub':
            ImageHubComponent,

        'overlay':
            OverlayComponent,

        'pagination':
            PaginationComponent,

        'search-dropdown':
            SearchDropdownComponent,

        'textarea':
            TextareaComponent,

        'text-box':
            TextboxComponent,

        'textbox':
            TextboxComponent,


        //=======================================================
        // Layout Components
        //=======================================================

        'breadcrumb':
            BreadcrumbComponent,

        'empty-state':
            EmptyStateComponent,

        'footer-brand':
            FooterBrandComponent,

        'footer-version':
            FooterVersionComponent,

        'form-grid':
            FormGridComponent,

        'form-section':
            FormSectionComponent,

        'inline-selection':
            InlineSelectionComponent,

        'item-cart':
            ItemCart,

        'list-table':
            ListTableComponent,

        'page-canvas':
            PageCanvasComponent,

        'page-header':
            PageHeaderComponent,

        'page-toolbar':
            PageToolbarComponent,

        'selection-panel':
            SelectionPanelComponent,

        'sidebar-footer':
            SidebarFooterComponent,

        'topbar-actions':
            TopbarActionsComponent,

        'topbar-header':
            TopbarHeaderComponent,


        //=======================================================
        // Utility Components
        //=======================================================

        'activity-selector':
            ActivitySelector,

        'checkbox':
            CheckboxComponent,

        'command-center':
            CommandCenterComponent,

        'confirm-dialog':
            ConfirmDialogComponent,

        'control-segment':
            ControlSegmentComponent,

        'git-message-modal':
            GitMessageModalComponent,

        'history-drawer':
            HistoryDrawerComponent,

        'orbit-loader':
            OrbitLoaderComponent,

        'progress-dialog':
            ProgressDialogComponent,

        'record-counter':
            RecordCounterComponent,

        'search-box':
            SearchBoxComponent,

        'toast':
            ToastComponent,


        //=======================================================
        // Sub-ordinate Components
        //=======================================================

        'background-image-1':
            BackgroundImageComponent,

        'background-image-2':
            BackgroundImageComponent2,

        'background-image-3':
            BackgroundImageComponent3,

        'background-image-4':
            BackgroundImageComponent4,

        'background-image-5':
            BackgroundImageComponent5
    };


    //===========================================================
    // Changes
    //===========================================================

    ngOnChanges
    (
        changes:
            SimpleChanges
    ):
        void
    {
        if
        (
            changes['componentKey']
            ||
            changes['lightBackgroundImageUrl']
            ||
            changes['deepBackgroundImageUrl']
        )
        {
            this.renderComponent();
        }
    }


    //===========================================================
    // Render Component
    //===========================================================

    private renderComponent():
        void
    {
        this.clearComponent();

        const componentType =
            this.resolveComponent(
                this.componentKey
            );

        if
        (
            !componentType
        )
        {
            return;
        }

        this.componentRef =
            this.componentHost.createComponent(
                componentType
            );


        //=======================================================
        // Background Image 1 Inputs
        //=======================================================

        if
        (
            this.componentKey
                .trim()
                .toLowerCase()
            ===
            'background-image-1'
        )
        {
            this.componentRef.setInput(
                'lightBackgroundImageUrl',
                this.lightBackgroundImageUrl
            );

            this.componentRef.setInput(
                'deepBackgroundImageUrl',
                this.deepBackgroundImageUrl
            );
        }


        //=======================================================
        // Explicit Dynamic Host Layout
        //=======================================================

        this.setComponentHostLayout();


        //=======================================================
        // Preview Mode
        //=======================================================

        this.setPreviewMode();


        //=======================================================
        // Change Detection
        //=======================================================

        this.cdr.detectChanges();
    }


    //===========================================================
    // Set Component Host Layout
    //===========================================================
    //
    // Most dynamic components use the complete preview surface.
    //
    // Change Password is different:
    //
    // Its native modal is intentionally designed at
    // 1190px × 690px.
    //
    // Therefore its host must preserve those native dimensions.
    //
    // The parent renderer remains responsible for applying the
    // preview scale.
    //
    // This prevents the Change Password modal from being forced
    // into the 16:9 preview container before scaling occurs.
    //
    //===========================================================

    private setComponentHostLayout():
        void
    {
        if
        (
            !this.componentRef
        )
        {
            return;
        }

        const hostElement =
            this.componentRef
                .location
                .nativeElement as
                HTMLElement;


        const normalizedKey =
            (
                this.componentKey
                ??
                ''
            )
            .trim()
            .toLowerCase();


        const isChangePassword =
            normalizedKey
                ===
                'change-password';


        //=======================================================
        // Common Host Styles
        //=======================================================

        hostElement.style.display =
            'block';

        hostElement.style.margin =
            '0';

        hostElement.style.padding =
            '0';

        hostElement.style.boxSizing =
            'border-box';

        hostElement.style.overflow =
            'visible';


        //=======================================================
        // Change Password Host
        //=======================================================
        //
        // Preserve the component's native modal dimensions.
        //
        // The renderer's CSS scale is applied to this complete
        // native-size component.
        //
        //=======================================================

        if
        (
            isChangePassword
        )
        {
            hostElement.style.position =
                'absolute';

            hostElement.style.width =
                '1190px';

            hostElement.style.minWidth =
                '1190px';

            hostElement.style.maxWidth =
                '1190px';

            hostElement.style.height =
                '690px';

            hostElement.style.minHeight =
                '690px';

            hostElement.style.maxHeight =
                '690px';

            hostElement.style.top =
                '50%';

            hostElement.style.left =
                '50%';

            hostElement.style.right =
                'auto';

            hostElement.style.bottom =
                'auto';

            hostElement.style.transform =
                'translate(-50%, -50%)';

            hostElement.style.flex =
                '0 0 1190px';

            hostElement.style.alignSelf =
                'auto';

            return;
        }


        //=======================================================
        // Standard Component Host Layout
        //=======================================================

        hostElement.style.position =
            'relative';

        hostElement.style.width =
            '100%';

        hostElement.style.minWidth =
            '0';

        hostElement.style.maxWidth =
            'none';

        hostElement.style.height =
            '100%';

        hostElement.style.minHeight =
            '0';

        hostElement.style.maxHeight =
            'none';

        hostElement.style.top =
            'auto';

        hostElement.style.left =
            'auto';

        hostElement.style.right =
            'auto';

        hostElement.style.bottom =
            'auto';

        hostElement.style.transform =
            'none';

        hostElement.style.flex =
            '0 0 auto';

        hostElement.style.alignSelf =
            'stretch';
    }


    //===========================================================
    // Set Preview Mode
    //===========================================================

    private setPreviewMode():
        void
    {
        if
        (
            !this.componentRef
        )
        {
            return;
        }

        const instance =
            this.componentRef.instance as
            {
                previewMode?:
                    boolean;
            };

        if
        (
            'previewMode' in instance
        )
        {
            this.componentRef.setInput(
                'previewMode',
                true
            );
        }
    }


    //===========================================================
    // Resolve Component
    //===========================================================

    private resolveComponent
    (
        componentKey:
            string
    ):
        Type<unknown>
        |
        null
    {
        const normalizedKey =
            (
                componentKey
                ??
                ''
            )
            .trim()
            .toLowerCase();

        if
        (
            !normalizedKey
        )
        {
            return null;
        }

        const directComponent =
            this.componentRegistry[
                normalizedKey
            ];

        if
        (
            directComponent
        )
        {
            return directComponent;
        }

        const normalizedPath =
            normalizedKey
                .replace(
                    /\\/g,
                    '/'
                )
                .replace(
                    /\/+/g,
                    '/'
                )
                .replace(
                    /\/$/,
                    ''
                );

        const pathParts =
            normalizedPath
                .split('/')
                .filter(
                    part =>
                        part.trim() !== ''
                );

        if
        (
            pathParts.length > 0
        )
        {
            const lastPathPart =
                pathParts[
                    pathParts.length - 1
                ].trim();

            const pathComponent =
                this.componentRegistry[
                    lastPathPart
                ];

            if
            (
                pathComponent
            )
            {
                return pathComponent;
            }
        }

        const displayKey =
            normalizedKey
                .replace(
                    /\\/g,
                    '/'
                )
                .split('/')
                .pop()
                ??
                normalizedKey;

        const componentName =
            displayKey
                .replace(
                    /\.[^/.]+$/,
                    ''
                )
                .replace(
                    /[_\s]+/g,
                    '-'
                )
                .replace(
                    /-+/g,
                    '-'
                )
                .trim()
                .toLowerCase();

        const displayComponent =
            this.componentRegistry[
                componentName
            ];

        if
        (
            displayComponent
        )
        {
            return displayComponent;
        }

        const displayText =
            displayKey
                .replace(
                    /[-_]+/g,
                    ' '
                )
                .replace(
                    /\s+/g,
                    ' '
                )
                .trim()
                .toLowerCase();

        for
        (
            const registryKey of
            Object.keys(
                this.componentRegistry
            )
        )
        {
            const registryDisplayText =
                registryKey
                    .replace(
                        /[-_]+/g,
                        ' '
                    )
                    .replace(
                        /\s+/g,
                        ' '
                    )
                    .trim()
                    .toLowerCase();

            if
            (
                registryDisplayText ===
                displayText
            )
            {
                return this.componentRegistry[
                    registryKey
                ];
            }
        }

        return null;
    }


    //===========================================================
    // Clear Component
    //===========================================================

    private clearComponent():
        void
    {
        if
        (
            this.componentRef
        )
        {
            this.componentRef.destroy();

            this.componentRef =
                null;
        }

        this.componentHost.clear();
    }

}